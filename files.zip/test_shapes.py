"""
Dummy-tensor shape/sanity test for UIENet + UNetDiscriminator.
Run: python test_shapes.py
"""
import torch
from uie_model import UIENet, UNetDiscriminator


def main():
    torch.manual_seed(0)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Device: {device}")

    B, C, H, W = 2, 3, 256, 256
    x = torch.rand(B, C, H, W, device=device)  # dummy "underwater image" batch, values in [0,1]

    model = UIENet(nf=64, n_encoder_blocks=4, n_refine_blocks=4, gc=32).to(device)
    model.eval()

    n_params = sum(p.numel() for p in model.parameters())
    print(f"UIENet parameters: {n_params:,}")

    with torch.no_grad():
        out, aux = model(x, return_aux=True)

    print("\n--- Shape check ---")
    print(f"input            : {tuple(x.shape)}")
    print(f"output           : {tuple(out.shape)}")
    for i, v in enumerate(aux["views"]):
        print(f"view[{i}]          : {tuple(v.shape)}")
    print(f"fusion gates     : {tuple(aux['gates'].shape)}  (B, n_views, C, H, W)")
    print(f"fused features   : {tuple(aux['fused'].shape)}")
    print(f"residual delta   : {tuple(aux['delta'].shape)}")

    assert out.shape == x.shape, "output shape must match input shape"
    assert out.min() >= 0.0 and out.max() <= 1.0, "output must be in [0,1]"
    # gates must sum to 1 across the view dimension at every (c,h,w)
    gate_sum = aux["gates"].sum(dim=1)
    assert torch.allclose(gate_sum, torch.ones_like(gate_sum), atol=1e-4), \
        "fusion gates must sum to 1 across views"
    print("\n[OK] output shape matches input, range in [0,1], fusion gates sum to 1 across views.")

    # quick gradient flow check
    model.train()
    x_grad = torch.rand(B, C, H, W, device=device, requires_grad=False)
    out2 = model(x_grad)
    loss = out2.mean()
    loss.backward()
    n_with_grad = sum(1 for p in model.parameters() if p.grad is not None and p.grad.abs().sum() > 0)
    n_total = sum(1 for _ in model.parameters())
    print(f"[OK] backward pass succeeded. Params receiving gradient: {n_with_grad}/{n_total}")

    # discriminator check
    disc = UNetDiscriminator(nf=64).to(device)
    with torch.no_grad():
        d_out = disc(out)
    print(f"\ndiscriminator out: {tuple(d_out.shape)}  (patch-realness map)")
    assert d_out.shape[0] == B and d_out.shape[2:] == x.shape[2:]
    print("[OK] discriminator output shape matches expected (B, 1, H, W).")

    # non-square, odd-ish resolution to make sure nothing hardcodes size
    x3 = torch.rand(1, 3, 180, 320, device=device)
    with torch.no_grad():
        out3 = model(x3)
    print(f"\nnon-square input {tuple(x3.shape)} -> output {tuple(out3.shape)}")
    assert out3.shape == x3.shape
    print("[OK] arbitrary resolution works (fully convolutional).")

    print("\nAll shape/sanity checks passed.")


if __name__ == "__main__":
    main()
