"""
Unified Underwater Image Enhancement (UIE) Model
==================================================

Architecture:
    Input -> 4 parallel views (Original, White-Balance, Contrast/HE, Gamma-Correction)
          -> Shared RRDB Encoder (weight-tied across views)
          -> Attention-Gated Fusion   [NOVEL]
          -> RRDB Refinement Trunk
          -> Reconstruction Head (residual) [NOVEL]
          -> Enhanced Image

Component provenance
---------------------
BORROWED / INSPIRED (cite explicitly in any writeup):
    - ResidualDenseBlock, RRDB, RRDBTrunk        -> Real-ESRGAN (Wang et al., 2021) / ESRGAN (Wang et al., 2018)
    - WhiteBalance, ContrastEqualization, GammaCorrection view generation
                                                  -> Water-Net (Li et al., 2019), classical UIE pipeline
    - UNetDiscriminator + spectral norm          -> Real-ESRGAN

NOVEL / OURS (this is the actual research contribution):
    - AttentionGatedFusion  (channel-SE gate x spatial gate x cross-view softmax)
    - The "4 parallel views -> 1 shared encoder -> learned fusion" topology itself
      (Water-Net uses a *fixed/learned confidence-map* blend of independently-processed
       branches; we instead force all views through *one shared encoder* into a common
       feature space, then gate *features*, not pixels, which lets the network correct
       WB/contrast/gamma errors it discovers only after feature extraction.)
    - Residual reconstruction head tied to the untouched original view (not to any
      pre-enhanced branch), keeping the network honest about what it changed.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


# ======================================================================================
# 1. PREPROCESSING  --  Water-Net inspired, classical & fixed (no learnable params)
# ======================================================================================
# These generate the 3 auxiliary "views" from the raw input. They run once per forward
# pass, are fully differentiable (implemented with batched torch ops, no per-image
# Python loops), and require input in [0, 1].

class WhiteBalance(nn.Module):
    """Gray-World white balance, batched.

    For each image, scale each channel so its mean equals the average of all
    channel means (the 'gray world' assumption). This is the classical WB used
    as one of Water-Net's three input branches.
    """
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, 3, H, W) in [0, 1]
        mean_c = x.mean(dim=(2, 3), keepdim=True)          # (B, 3, 1, 1)
        gray = mean_c.mean(dim=1, keepdim=True)             # (B, 1, 1, 1)
        scale = gray / (mean_c + 1e-6)
        out = x * scale
        return out.clamp(0.0, 1.0)


class ContrastEqualization(nn.Module):
    """Batched percentile contrast-stretch, a differentiable stand-in for
    histogram equalization (true per-pixel HE is not batch/GPU friendly).

    Stretches the [low_pct, high_pct] intensity window of each channel of each
    image to [0, 1]. Produces the same qualitative effect as HE: it expands
    the dominant mid-range of underwater images that HE/CLAHE targets in
    Water-Net.
    """
    def __init__(self, low_pct: float = 0.01, high_pct: float = 0.99):
        super().__init__()
        self.low_pct = low_pct
        self.high_pct = high_pct

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, h, w = x.shape
        flat = x.reshape(b, c, h * w)
        lo = torch.quantile(flat, self.low_pct, dim=2, keepdim=True)   # (B, C, 1)
        hi = torch.quantile(flat, self.high_pct, dim=2, keepdim=True)  # (B, C, 1)
        lo = lo.unsqueeze(-1)   # (B, C, 1, 1)
        hi = hi.unsqueeze(-1)
        out = (x - lo) / (hi - lo + 1e-6)
        return out.clamp(0.0, 1.0)


class GammaCorrection(nn.Module):
    """Adaptive gamma correction: picks gamma per-image so the mean luminance
    maps to a target value (default 0.5). Brightens dark, low-contrast
    underwater frames -- Water-Net's third input branch.
    """
    def __init__(self, target: float = 0.5, eps: float = 1e-3):
        super().__init__()
        self.target = target
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # luminance per image
        lum = (0.299 * x[:, 0] + 0.587 * x[:, 1] + 0.114 * x[:, 2]).mean(dim=(1, 2))
        lum = lum.clamp(min=self.eps, max=1 - self.eps)
        gamma = torch.log(torch.full_like(lum, self.target)) / torch.log(lum)
        gamma = gamma.clamp(0.3, 3.0).view(-1, 1, 1, 1)  # (B,1,1,1)
        out = torch.pow(x.clamp(min=self.eps), gamma)
        return out.clamp(0.0, 1.0)


class MultiViewGenerator(nn.Module):
    """Produces the 4 parallel views: [Original, WB, Contrast, GammaCorrection]."""
    def __init__(self):
        super().__init__()
        self.wb = WhiteBalance()
        self.ce = ContrastEqualization()
        self.gc = GammaCorrection()

    def forward(self, x: torch.Tensor):
        v0 = x
        v1 = self.wb(x)
        v2 = self.ce(x)
        v3 = self.gc(x)
        return [v0, v1, v2, v3]  # each (B, 3, H, W)


# ======================================================================================
# 2. RRDB BACKBONE  --  Real-ESRGAN / ESRGAN inspired (borrowed, standard)
# ======================================================================================

class ResidualDenseBlock(nn.Module):
    """5-conv Residual Dense Block, as in ESRGAN/Real-ESRGAN."""
    def __init__(self, nf: int = 64, gc: int = 32, res_scale: float = 0.2):
        super().__init__()
        self.res_scale = res_scale
        self.conv1 = nn.Conv2d(nf, gc, 3, 1, 1)
        self.conv2 = nn.Conv2d(nf + gc, gc, 3, 1, 1)
        self.conv3 = nn.Conv2d(nf + 2 * gc, gc, 3, 1, 1)
        self.conv4 = nn.Conv2d(nf + 3 * gc, gc, 3, 1, 1)
        self.conv5 = nn.Conv2d(nf + 4 * gc, nf, 3, 1, 1)
        self.lrelu = nn.LeakyReLU(0.2, inplace=True)
        self._init_weights()

    def _init_weights(self):
        # small init on the last conv keeps the residual branch near-identity at start
        for m in [self.conv1, self.conv2, self.conv3, self.conv4]:
            nn.init.kaiming_normal_(m.weight, a=0.2, mode="fan_in", nonlinearity="leaky_relu")
            m.weight.data *= 0.1
            nn.init.zeros_(m.bias)
        nn.init.kaiming_normal_(self.conv5.weight, a=0.2, mode="fan_in", nonlinearity="leaky_relu")
        self.conv5.weight.data *= 0.1
        nn.init.zeros_(self.conv5.bias)

    def forward(self, x):
        x1 = self.lrelu(self.conv1(x))
        x2 = self.lrelu(self.conv2(torch.cat([x, x1], 1)))
        x3 = self.lrelu(self.conv3(torch.cat([x, x1, x2], 1)))
        x4 = self.lrelu(self.conv4(torch.cat([x, x1, x2, x3], 1)))
        x5 = self.conv5(torch.cat([x, x1, x2, x3, x4], 1))
        return x + x5 * self.res_scale


class RRDB(nn.Module):
    """Residual-in-Residual Dense Block: 3 stacked RDBs + outer residual, as in
    ESRGAN / Real-ESRGAN."""
    def __init__(self, nf: int = 64, gc: int = 32, res_scale: float = 0.2):
        super().__init__()
        self.res_scale = res_scale
        self.rdb1 = ResidualDenseBlock(nf, gc, res_scale)
        self.rdb2 = ResidualDenseBlock(nf, gc, res_scale)
        self.rdb3 = ResidualDenseBlock(nf, gc, res_scale)

    def forward(self, x):
        out = self.rdb1(x)
        out = self.rdb2(out)
        out = self.rdb3(out)
        return x + out * self.res_scale


class RRDBTrunk(nn.Module):
    """Stack of N RRDB blocks + trunk conv, used both as the shared encoder and
    as the post-fusion refinement trunk (same building block, different depth /
    different role in the pipeline -- weights are NOT shared between the two
    usages)."""
    def __init__(self, nf: int = 64, n_blocks: int = 6, gc: int = 32):
        super().__init__()
        self.blocks = nn.Sequential(*[RRDB(nf, gc) for _ in range(n_blocks)])
        self.trunk_conv = nn.Conv2d(nf, nf, 3, 1, 1)

    def forward(self, x):
        out = self.blocks(x)
        out = self.trunk_conv(out)
        return x + out  # global residual over the whole trunk


class SharedRRDBEncoder(nn.Module):
    """conv_in (3->nf) followed by an RRDBTrunk. Applied with SHARED weights to
    each of the 4 views -- this is what forces WB/contrast/gamma/original into
    one common feature space instead of 4 independent feature spaces."""
    def __init__(self, nf: int = 64, n_blocks: int = 6, gc: int = 32):
        super().__init__()
        self.conv_in = nn.Conv2d(3, nf, 3, 1, 1)
        self.trunk = RRDBTrunk(nf, n_blocks, gc)

    def forward(self, x):
        feat = self.conv_in(x)
        feat = self.trunk(feat)
        return feat  # (B, nf, H, W)


# ======================================================================================
# 3. ATTENTION-GATED FUSION  --  ★ NOVEL, this is the proposed contribution ★
# ======================================================================================

class AttentionGatedFusion(nn.Module):
    """Adaptively fuses V feature maps (one per view) into a single feature map.

    For each view i we compute a gate G_i(b, c, h, w) built from two cheap,
    complementary attention signals:

      - Channel gate  (Squeeze-Excitation style): "how useful is channel c of
        view i overall, for this image" -- captures things like "the WB view's
        color channels are more trustworthy than the raw image's".
      - Spatial gate  (1x1 conv over concatenated views): "how useful is
        location (h, w) of view i" -- captures things like "the contrast view
        recovers detail here, but oversaturates that patch over there".

    The two signals are multiplied to form a per-view, per-channel, per-pixel
    logit, and a SOFTMAX is taken *across the view dimension* so that, at every
    single (channel, pixel) location, the 4 views' contributions sum to 1. This
    is the key structural difference from Water-Net's confidence-map fusion
    (which blends raw RGB *pixels* with learned scalar-per-pixel maps): here we
    gate *deep features*, after they've already gone through a shared encoder,
    so the network can fuse based on abstracted content/texture agreement
    between views, not just their raw colors.

    Output has the same shape as a single view's feature map: (B, C, H, W).
    """
    def __init__(self, nf: int = 64, n_views: int = 4, reduction: int = 8):
        super().__init__()
        self.n_views = n_views

        # Channel attention: shared MLP applied per-view after global pooling
        self.channel_mlp = nn.Sequential(
            nn.Conv2d(nf, nf // reduction, 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(nf // reduction, nf, 1),
        )

        # Spatial attention: looks at ALL views jointly (cross-view context)
        # to decide each view's per-pixel weight -> lets it use e.g. "does the
        # WB view agree with the contrast view here?" as a signal.
        self.spatial_conv = nn.Sequential(
            nn.Conv2d(nf * n_views, nf, 3, 1, 1),
            nn.LeakyReLU(0.2, inplace=True),
            nn.Conv2d(nf, n_views, 3, 1, 1),  # one spatial logit map per view
        )

        # Small conv to mix the fused result with a cross-view concat feature
        # (cheap extra context path, keeps a gradient route that bypasses the
        # softmax bottleneck).
        self.post_mix = nn.Conv2d(nf, nf, 3, 1, 1)

    def forward(self, feats):
        """
        feats: list of V tensors, each (B, nf, H, W)
        returns: fused (B, nf, H, W)
        """
        assert len(feats) == self.n_views
        b, c, h, w = feats[0].shape

        # ---- channel logits per view: (B, C, 1, 1) each ----
        channel_logits = []
        for f in feats:
            pooled = f.mean(dim=(2, 3), keepdim=True)          # (B, C, 1, 1)
            channel_logits.append(self.channel_mlp(pooled))     # (B, C, 1, 1)
        channel_logits = torch.stack(channel_logits, dim=1)     # (B, V, C, 1, 1)

        # ---- spatial logits per view: (B, 1, H, W) each ----
        concat = torch.cat(feats, dim=1)                        # (B, V*C, H, W)
        spatial_logits = self.spatial_conv(concat)              # (B, V, H, W)
        spatial_logits = spatial_logits.unsqueeze(2)             # (B, V, 1, H, W)

        # ---- combine and normalize across the VIEW dimension ----
        logits = channel_logits + spatial_logits                 # broadcast -> (B, V, C, H, W)
        gates = torch.softmax(logits, dim=1)                     # sums to 1 across views

        stacked = torch.stack(feats, dim=1)                      # (B, V, C, H, W)
        fused = (gates * stacked).sum(dim=1)                     # (B, C, H, W)

        fused = fused + self.post_mix(fused)
        return fused, gates  # return gates too -- useful for visualization/debugging


# ======================================================================================
# 4. RECONSTRUCTION HEAD  --  novel wiring (simple convs, but tied to raw input)
# ======================================================================================

class ReconstructionHead(nn.Module):
    """Maps refined features back to an RGB residual, added onto the UNTOUCHED
    original view (not any pre-enhanced branch). This keeps a clean identity
    path: if the network learns nothing, output == input, and every visible
    correction is an explicit, learned delta.
    """
    def __init__(self, nf: int = 64):
        super().__init__()
        self.conv1 = nn.Conv2d(nf, nf // 2, 3, 1, 1)
        self.conv2 = nn.Conv2d(nf // 2, 3, 3, 1, 1)
        self.lrelu = nn.LeakyReLU(0.2, inplace=True)
        nn.init.zeros_(self.conv2.weight)  # start as identity: delta ~ 0
        nn.init.zeros_(self.conv2.bias)

    def forward(self, feat, original_view):
        delta = self.conv2(self.lrelu(self.conv1(feat)))
        out = original_view + delta
        return out.clamp(0.0, 1.0), delta


# ======================================================================================
# 5. FULL MODEL
# ======================================================================================

class UIENet(nn.Module):
    """Unified Underwater Image Enhancement network.

    Args:
        nf: base feature width
        n_encoder_blocks: RRDB depth of the SHARED encoder (applied to each of the 4 views)
        n_refine_blocks: RRDB depth of the post-fusion refinement trunk
        gc: growth channel inside each RRDB
    """
    def __init__(self, nf: int = 64, n_encoder_blocks: int = 6,
                 n_refine_blocks: int = 6, gc: int = 32):
        super().__init__()
        self.view_gen = MultiViewGenerator()                       # borrowed idea (Water-Net), fixed ops
        self.encoder = SharedRRDBEncoder(nf, n_encoder_blocks, gc)  # borrowed block (Real-ESRGAN), SHARED weights
        self.fusion = AttentionGatedFusion(nf, n_views=4)           # NOVEL
        self.refine = RRDBTrunk(nf, n_refine_blocks, gc)            # borrowed block, new usage (post-fusion)
        self.recon = ReconstructionHead(nf)                         # novel wiring

    def forward(self, x: torch.Tensor, return_aux: bool = False):
        """
        x: (B, 3, H, W) in [0, 1]
        """
        views = self.view_gen(x)                       # list of 4 x (B,3,H,W)
        feats = [self.encoder(v) for v in views]        # list of 4 x (B,nf,H,W), SHARED weights
        fused, gates = self.fusion(feats)                # (B,nf,H,W)
        refined = self.refine(fused)                     # (B,nf,H,W)
        out, delta = self.recon(refined, views[0])        # (B,3,H,W), residual on ORIGINAL view

        if return_aux:
            return out, {"views": views, "gates": gates, "delta": delta, "fused": fused}
        return out


# ======================================================================================
# 6. DISCRIMINATOR  --  Real-ESRGAN inspired, borrowed (optional, training-only)
# ======================================================================================

def spectral_norm_conv(*args, **kwargs):
    return nn.utils.spectral_norm(nn.Conv2d(*args, **kwargs))


class UNetDiscriminator(nn.Module):
    """U-Net discriminator with spectral normalization, as used in Real-ESRGAN.
    Operates at the SAME resolution as the enhanced image (no downsampling of
    the task itself -- UIE is not super-resolution, so this discriminator does
    not upsample either, unlike Real-ESRGAN's SR discriminator).
    """
    def __init__(self, nf: int = 64):
        super().__init__()
        self.conv0 = nn.Conv2d(3, nf, 3, 1, 1)

        self.down1 = spectral_norm_conv(nf, nf * 2, 4, 2, 1)
        self.down2 = spectral_norm_conv(nf * 2, nf * 4, 4, 2, 1)
        self.down3 = spectral_norm_conv(nf * 4, nf * 8, 4, 2, 1)

        self.up1 = spectral_norm_conv(nf * 8, nf * 4, 3, 1, 1)
        self.up2 = spectral_norm_conv(nf * 4, nf * 2, 3, 1, 1)
        self.up3 = spectral_norm_conv(nf * 2, nf, 3, 1, 1)

        self.final1 = spectral_norm_conv(nf, nf, 3, 1, 1)
        self.final2 = spectral_norm_conv(nf, nf, 3, 1, 1)
        self.final3 = nn.Conv2d(nf, 1, 3, 1, 1)

        self.lrelu = nn.LeakyReLU(0.2, inplace=True)

    def forward(self, x):
        x0 = self.lrelu(self.conv0(x))
        x1 = self.lrelu(self.down1(x0))
        x2 = self.lrelu(self.down2(x1))
        x3 = self.lrelu(self.down3(x2))

        x3 = F.interpolate(x3, scale_factor=2, mode="bilinear", align_corners=False)
        x4 = self.lrelu(self.up1(x3)) + x2
        x4 = F.interpolate(x4, scale_factor=2, mode="bilinear", align_corners=False)
        x5 = self.lrelu(self.up2(x4)) + x1
        x5 = F.interpolate(x5, scale_factor=2, mode="bilinear", align_corners=False)
        x6 = self.lrelu(self.up3(x5)) + x0

        out = self.lrelu(self.final1(x6))
        out = self.lrelu(self.final2(out))
        out = self.final3(out)
        return out  # (B, 1, H, W) patch-realness map
