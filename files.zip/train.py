"""
Training script for UIENet on paired underwater data:
    raw/    -- degraded underwater images
    ref/    -- corresponding ground-truth (clean) reference images
Filenames must match between the two folders (e.g. raw/0001.png <-> ref/0001.png).

Two-phase training, matching common UIE / Real-ESRGAN practice:
  Phase 1 (pixel + perceptual):  stable, fast, gets colors/structure right.
  Phase 2 (+ adversarial, optional): sharpens fine texture using UNetDiscriminator.

Usage:
    python train.py --data_dir /path/to/data --epochs 100 --gan_start_epoch 60
"""
import argparse
import os
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models

from uie_model import UIENet, UNetDiscriminator


# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------
class PairedUIEDataset(Dataset):
    """Expects:
        data_dir/raw/<name>.png  (underwater / degraded)
        data_dir/ref/<name>.png  (clean reference)
    """
    IMG_EXTS = {".png", ".jpg", ".jpeg", ".bmp"}

    def __init__(self, data_dir: str, crop_size: int = 256, train: bool = True):
        self.raw_dir = Path(data_dir) / "raw"
        self.ref_dir = Path(data_dir) / "ref"
        self.names = sorted(
            p.name for p in self.raw_dir.iterdir() if p.suffix.lower() in self.IMG_EXTS
        )
        missing = [n for n in self.names if not (self.ref_dir / n).exists()]
        if missing:
            raise FileNotFoundError(
                f"{len(missing)} raw images have no matching reference, e.g. {missing[:3]}"
            )
        self.crop_size = crop_size
        self.train = train
        self.to_tensor = transforms.ToTensor()

    def __len__(self):
        return len(self.names)

    def _sync_augment(self, raw_img, ref_img):
        from PIL import Image
        # resize shorter side to at least crop_size, keep raw/ref in sync
        w, h = raw_img.size
        scale = self.crop_size / min(w, h)
        if scale > 1.0:
            new_size = (max(self.crop_size, int(w * scale)), max(self.crop_size, int(h * scale)))
            raw_img = raw_img.resize(new_size, Image.BICUBIC)
            ref_img = ref_img.resize(new_size, Image.BICUBIC)
            w, h = new_size

        if self.train:
            import random
            x0 = random.randint(0, w - self.crop_size)
            y0 = random.randint(0, h - self.crop_size)
            raw_img = raw_img.crop((x0, y0, x0 + self.crop_size, y0 + self.crop_size))
            ref_img = ref_img.crop((x0, y0, x0 + self.crop_size, y0 + self.crop_size))
            if random.random() < 0.5:
                raw_img = raw_img.transpose(Image.FLIP_LEFT_RIGHT)
                ref_img = ref_img.transpose(Image.FLIP_LEFT_RIGHT)
        else:
            left = (w - self.crop_size) // 2
            top = (h - self.crop_size) // 2
            raw_img = raw_img.crop((left, top, left + self.crop_size, top + self.crop_size))
            ref_img = ref_img.crop((left, top, left + self.crop_size, top + self.crop_size))
        return raw_img, ref_img

    def __getitem__(self, idx):
        from PIL import Image
        name = self.names[idx]
        raw_img = Image.open(self.raw_dir / name).convert("RGB")
        ref_img = Image.open(self.ref_dir / name).convert("RGB")
        raw_img, ref_img = self._sync_augment(raw_img, ref_img)
        return self.to_tensor(raw_img), self.to_tensor(ref_img)


# ---------------------------------------------------------------------------
# Losses
# ---------------------------------------------------------------------------
class CharbonnierLoss(nn.Module):
    """Smooth L1 variant, standard for image restoration (robust to outliers,
    better gradients near 0 than plain L1)."""
    def __init__(self, eps: float = 1e-3):
        super().__init__()
        self.eps2 = eps ** 2

    def forward(self, pred, target):
        diff = pred - target
        return torch.sqrt(diff * diff + self.eps2).mean()


class VGGPerceptualLoss(nn.Module):
    """Perceptual loss using VGG19 features (ImageNet-pretrained), standard
    choice in Real-ESRGAN / SRGAN-family losses."""
    def __init__(self, layer_idx: int = 35):  # relu5_4-ish region in vgg19.features
        super().__init__()
        vgg = models.vgg19(weights=models.VGG19_Weights.IMAGENET1K_V1).features[:layer_idx].eval()
        for p in vgg.parameters():
            p.requires_grad = False
        self.vgg = vgg
        self.register_buffer("mean", torch.tensor([0.485, 0.456, 0.406]).view(1, 3, 1, 1))
        self.register_buffer("std", torch.tensor([0.229, 0.224, 0.225]).view(1, 3, 1, 1))

    def forward(self, pred, target):
        pred_n = (pred - self.mean) / self.std
        target_n = (target - self.mean) / self.std
        return F.l1_loss(self.vgg(pred_n), self.vgg(target_n))


def gan_loss(pred_logits, is_real: bool):
    """Non-saturating BCE-with-logits GAN loss (standard, matches Real-ESRGAN)."""
    target = torch.ones_like(pred_logits) if is_real else torch.zeros_like(pred_logits)
    return F.binary_cross_entropy_with_logits(pred_logits, target)


# ---------------------------------------------------------------------------
# Training loop
# ---------------------------------------------------------------------------
def train(args):
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")

    train_ds = PairedUIEDataset(args.data_dir, crop_size=args.crop_size, train=True)
    train_loader = DataLoader(
        train_ds, batch_size=args.batch_size, shuffle=True,
        num_workers=args.num_workers, pin_memory=True, drop_last=True,
    )
    print(f"Training pairs: {len(train_ds)}")

    model = UIENet(nf=args.nf, n_encoder_blocks=args.n_enc, n_refine_blocks=args.n_ref).to(device)
    disc = UNetDiscriminator(nf=args.nf).to(device) if args.use_gan else None

    charbonnier = CharbonnierLoss().to(device)
    perceptual = VGGPerceptualLoss().to(device) if args.use_perceptual else None

    opt_g = torch.optim.Adam(model.parameters(), lr=args.lr, betas=(0.9, 0.99))
    sched_g = torch.optim.lr_scheduler.CosineAnnealingLR(opt_g, T_max=args.epochs)

    opt_d, sched_d = None, None
    if args.use_gan:
        opt_d = torch.optim.Adam(disc.parameters(), lr=args.lr, betas=(0.9, 0.99))
        sched_d = torch.optim.lr_scheduler.CosineAnnealingLR(opt_d, T_max=args.epochs)

    ckpt_dir = Path(args.ckpt_dir)
    ckpt_dir.mkdir(parents=True, exist_ok=True)

    step = 0
    for epoch in range(args.epochs):
        model.train()
        gan_active = args.use_gan and epoch >= args.gan_start_epoch

        for raw, ref in train_loader:
            raw, ref = raw.to(device), ref.to(device)

            # ---------------- Generator step ----------------
            out = model(raw)

            loss_pix = charbonnier(out, ref)
            loss = args.w_pixel * loss_pix

            if perceptual is not None:
                loss_perc = perceptual(out, ref)
                loss = loss + args.w_perceptual * loss_perc
            else:
                loss_perc = torch.tensor(0.0)

            if gan_active:
                for p in disc.parameters():
                    p.requires_grad_(False)
                pred_fake = disc(out)
                loss_g_gan = gan_loss(pred_fake, is_real=True)  # generator wants disc to say "real"
                loss = loss + args.w_gan * loss_g_gan
            else:
                loss_g_gan = torch.tensor(0.0)

            opt_g.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            opt_g.step()

            # ---------------- Discriminator step ----------------
            loss_d = torch.tensor(0.0)
            if gan_active:
                for p in disc.parameters():
                    p.requires_grad_(True)
                pred_real = disc(ref)
                pred_fake = disc(out.detach())
                loss_d = 0.5 * (gan_loss(pred_real, is_real=True) + gan_loss(pred_fake, is_real=False))

                opt_d.zero_grad(set_to_none=True)
                loss_d.backward()
                opt_d.step()

            if step % args.log_every == 0:
                print(
                    f"epoch {epoch:03d} step {step:06d} | "
                    f"pix {loss_pix.item():.4f} perc {loss_perc.item():.4f} "
                    f"g_gan {loss_g_gan.item():.4f} d {loss_d.item():.4f}"
                )
            step += 1

        sched_g.step()
        if sched_d is not None:
            sched_d.step()

        if (epoch + 1) % args.save_every == 0 or epoch == args.epochs - 1:
            torch.save(
                {"model": model.state_dict(), "epoch": epoch},
                ckpt_dir / f"uienet_epoch{epoch+1}.pt",
            )
            if disc is not None:
                torch.save(disc.state_dict(), ckpt_dir / f"disc_epoch{epoch+1}.pt")
            print(f"Saved checkpoint at epoch {epoch+1}")

    print("Training complete.")


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--data_dir", type=str, required=True, help="dir containing raw/ and ref/ subfolders")
    p.add_argument("--ckpt_dir", type=str, default="./checkpoints")
    p.add_argument("--epochs", type=int, default=100)
    p.add_argument("--batch_size", type=int, default=8)
    p.add_argument("--crop_size", type=int, default=256)
    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--lr", type=float, default=2e-4)
    p.add_argument("--nf", type=int, default=64)
    p.add_argument("--n_enc", type=int, default=6, help="RRDB depth of shared encoder")
    p.add_argument("--n_ref", type=int, default=6, help="RRDB depth of refinement trunk")
    p.add_argument("--use_perceptual", action="store_true", default=True)
    p.add_argument("--use_gan", action="store_true", default=False)
    p.add_argument("--gan_start_epoch", type=int, default=60, help="start adversarial loss only after G is stable")
    p.add_argument("--w_pixel", type=float, default=1.0)
    p.add_argument("--w_perceptual", type=float, default=0.1)
    p.add_argument("--w_gan", type=float, default=0.01)
    p.add_argument("--log_every", type=int, default=50)
    p.add_argument("--save_every", type=int, default=10)
    return p.parse_args()


if __name__ == "__main__":
    train(parse_args())
